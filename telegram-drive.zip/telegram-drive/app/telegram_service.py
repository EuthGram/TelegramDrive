"""
Telegram service layer.

All actual Telegram/MTProto operations go through Telethon here.
This module never talks to the frontend directly and never logs
API hashes, session strings, or passwords.

Design notes for hosting-constrained environments (shared cPanel, etc.):
- We do NOT keep a long-running Telegram client per user in the background.
  Instead, each request that needs Telegram connects a client, performs the
  operation, and disconnects. This avoids requiring a persistent worker
  process, which many shared hosts don't support well.
- The exception is the *login* flow (send code -> submit code -> submit
  2FA password), which needs the same client across a few requests. That
  in-progress client is held in an in-memory registry keyed by a random
  token. This assumes a single-process deployment for the login flow only
  (fine for Gunicorn with 1 worker, or add "--preload" + sticky sessions
  for more). See README for scaling notes.
"""
import time
import secrets
import mimetypes
from dataclasses import dataclass, field

from telethon import TelegramClient
from telethon.sessions import StringSession
from telethon.errors import (
    ApiIdInvalidError,
    PhoneNumberInvalidError,
    PhoneCodeInvalidError,
    PhoneCodeExpiredError,
    SessionPasswordNeededError,
    PasswordHashInvalidError,
    FloodWaitError,
    RPCError,
)
from telethon.tl.functions.channels import (
    CreateChannelRequest,
    EditTitleRequest,
    DeleteChannelRequest,
)
from telethon.tl.functions.messages import DeleteChatRequest

from app.security import encrypt_secret, decrypt_secret


class TelegramServiceError(Exception):
    """User-facing Telegram error with a friendly message."""
    def __init__(self, message: str, code: str = "telegram_error"):
        super().__init__(message)
        self.message = message
        self.code = code


class TwoFactorRequired(Exception):
    """Raised when Telegram requests the 2FA cloud password."""
    pass


# ---------------------------------------------------------------------------
# In-memory registry for in-progress logins (send_code -> sign_in)
# ---------------------------------------------------------------------------
@dataclass
class _PendingLogin:
    client: TelegramClient
    api_id: str
    api_hash: str
    phone: str
    phone_code_hash: str
    created_at: float = field(default_factory=time.time)


_pending_logins: dict[str, _PendingLogin] = {}
_PENDING_TTL_SECONDS = 600


def _cleanup_pending():
    now = time.time()
    stale = [k for k, v in _pending_logins.items() if now - v.created_at > _PENDING_TTL_SECONDS]
    for k in stale:
        try:
            _pending_logins[k].client.disconnect()
        except Exception:
            pass
        _pending_logins.pop(k, None)


def _friendly_error(exc: Exception) -> TelegramServiceError:
    if isinstance(exc, ApiIdInvalidError):
        return TelegramServiceError("The API ID / API Hash pair is invalid.", "invalid_api")
    if isinstance(exc, PhoneNumberInvalidError):
        return TelegramServiceError("That phone number is invalid.", "invalid_phone")
    if isinstance(exc, PhoneCodeInvalidError):
        return TelegramServiceError("The verification code is incorrect.", "invalid_code")
    if isinstance(exc, PhoneCodeExpiredError):
        return TelegramServiceError("The verification code expired. Please request a new one.", "code_expired")
    if isinstance(exc, PasswordHashInvalidError):
        return TelegramServiceError("Incorrect Two-Step Verification password.", "invalid_2fa")
    if isinstance(exc, FloodWaitError):
        return TelegramServiceError(
            f"Telegram is rate-limiting this action. Please wait {exc.seconds} seconds and try again.",
            "flood_wait",
        )
    if isinstance(exc, RPCError):
        return TelegramServiceError(f"Telegram error: {exc.message}", "rpc_error")
    return TelegramServiceError(f"Unexpected error: {exc}", "unknown_error")


# ---------------------------------------------------------------------------
# Login flow
# ---------------------------------------------------------------------------
async def start_login(api_id: str, api_hash: str, phone: str) -> str:
    """
    Begins the Telegram login flow. Returns an opaque token to be used
    for the follow-up submit_code() call. The token is safe to keep in
    the browser session (it is not a secret credential itself).
    """
    _cleanup_pending()
    try:
        api_id_int = int(api_id)
    except ValueError:
        raise TelegramServiceError("API ID must be numeric.", "invalid_api")

    client = TelegramClient(StringSession(), api_id_int, api_hash)
    try:
        await client.connect()
        sent = await client.send_code_request(phone)
    except Exception as exc:
        try:
            await client.disconnect()
        except Exception:
            pass
        raise _friendly_error(exc)

    token = secrets.token_urlsafe(24)
    _pending_logins[token] = _PendingLogin(
        client=client,
        api_id=api_id,
        api_hash=api_hash,
        phone=phone,
        phone_code_hash=sent.phone_code_hash,
    )
    return token


async def submit_code(token: str, code: str) -> dict:
    """
    Submits the OTP code. On success returns a dict with the connection
    info needed to persist the account. Raises TwoFactorRequired if the
    account has Two-Step Verification enabled (call submit_password next).
    """
    pending = _pending_logins.get(token)
    if not pending:
        raise TelegramServiceError("This login attempt expired. Please start again.", "expired")

    try:
        await pending.client.sign_in(
            phone=pending.phone, code=code, phone_code_hash=pending.phone_code_hash
        )
    except SessionPasswordNeededError:
        raise TwoFactorRequired()
    except Exception as exc:
        raise _friendly_error(exc)

    return await _finish_login(token)


async def submit_password(token: str, password: str) -> dict:
    pending = _pending_logins.get(token)
    if not pending:
        raise TelegramServiceError("This login attempt expired. Please start again.", "expired")

    try:
        await pending.client.sign_in(password=password)
    except Exception as exc:
        raise _friendly_error(exc)

    return await _finish_login(token)


async def _finish_login(token: str) -> dict:
    pending = _pending_logins.pop(token)
    client = pending.client
    try:
        me = await client.get_me()
        session_string = client.session.save()
    finally:
        try:
            await client.disconnect()
        except Exception:
            pass

    return {
        "api_id": pending.api_id,
        "api_hash": pending.api_hash,
        "phone": pending.phone,
        "session_string": session_string,
        "telegram_user_id": me.id,
        "first_name": me.first_name,
        "username": me.username,
    }


def cancel_login(token: str) -> None:
    pending = _pending_logins.pop(token, None)
    if pending:
        try:
            pending.client.disconnect()
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Per-request client for an already-connected account
# ---------------------------------------------------------------------------
class ConnectedClient:
    """Async context manager: connects on enter, disconnects on exit."""

    def __init__(self, telegram_account):
        self.account = telegram_account
        self.client: TelegramClient | None = None

    async def __aenter__(self) -> TelegramClient:
        api_hash = decrypt_secret(self.account.api_hash_enc)
        session_str = decrypt_secret(self.account.session_enc)
        self.client = TelegramClient(
            StringSession(session_str), int(self.account.api_id), api_hash
        )
        try:
            await self.client.connect()
        except Exception as exc:
            raise _friendly_error(exc)
        if not await self.client.is_user_authorized():
            raise TelegramServiceError(
                "Your Telegram session has expired. Please reconnect Telegram.", "session_expired"
            )
        return self.client

    async def __aexit__(self, exc_type, exc, tb):
        if self.client:
            try:
                await self.client.disconnect()
            except Exception:
                pass


# ---------------------------------------------------------------------------
# Storage (channel / group) management
# ---------------------------------------------------------------------------
async def create_channel(client: TelegramClient, title: str, about: str = "Telegram Drive Storage"):
    try:
        result = await client(CreateChannelRequest(
            title=title, about=about, megagroup=False
        ))
        chat = result.chats[0]
        return chat.id, _full_chat_id(chat)
    except Exception as exc:
        raise _friendly_error(exc)


async def create_group(client: TelegramClient, title: str, about: str = "Telegram Drive Storage"):
    try:
        result = await client(CreateChannelRequest(
            title=title, about=about, megagroup=True
        ))
        chat = result.chats[0]
        return chat.id, _full_chat_id(chat)
    except Exception as exc:
        raise _friendly_error(exc)


def _full_chat_id(chat) -> int:
    """Telethon channel/supergroup IDs need the -100 prefix to be used as chat ids."""
    return int(f"-100{chat.id}")


async def rename_chat(client: TelegramClient, telegram_chat_id: int, new_title: str):
    try:
        entity = await client.get_entity(telegram_chat_id)
        await client(EditTitleRequest(channel=entity, title=new_title))
    except Exception as exc:
        raise _friendly_error(exc)


async def delete_storage_chat(client: TelegramClient, telegram_chat_id: int, chat_type: str):
    try:
        entity = await client.get_entity(telegram_chat_id)
        if chat_type in ("channel", "group"):
            await client(DeleteChannelRequest(channel=entity))
        else:
            await client(DeleteChatRequest(chat_id=entity.id))
    except Exception as exc:
        raise _friendly_error(exc)


# ---------------------------------------------------------------------------
# File upload / download / delete
# ---------------------------------------------------------------------------
def guess_category(filename: str, mime_type: str | None) -> str:
    mime_type = mime_type or mimetypes.guess_type(filename)[0] or ""
    if mime_type.startswith("image/"):
        return "image"
    if mime_type.startswith("video/"):
        return "video"
    if mime_type.startswith("audio/"):
        return "audio"
    if mime_type in ("application/pdf",) or filename.lower().endswith(
        (".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".txt", ".zip", ".rar", ".7z")
    ):
        return "document"
    return "other"


async def upload_file_to_chat(client: TelegramClient, telegram_chat_id: int, file_path: str, filename: str):
    try:
        entity = await client.get_entity(telegram_chat_id)
        message = await client.send_file(
            entity, file_path, caption=filename, force_document=False
        )
        return message.id
    except Exception as exc:
        raise _friendly_error(exc)


async def download_file_from_chat(client: TelegramClient, telegram_chat_id: int, message_id: int, dest_path: str):
    try:
        entity = await client.get_entity(telegram_chat_id)
        message = await client.get_messages(entity, ids=message_id)
        if message is None or not message.media:
            raise TelegramServiceError("The original file could not be found on Telegram.", "not_found")
        await client.download_media(message, file=dest_path)
        return dest_path
    except TelegramServiceError:
        raise
    except Exception as exc:
        raise _friendly_error(exc)


def generate_image_thumbnail_b64(file_path: str, max_size: int = 200) -> str | None:
    """Builds a small local thumbnail for an image file (does not touch Telegram)."""
    try:
        from PIL import Image
        import io
        import base64

        with Image.open(file_path) as img:
            img = img.convert("RGB")
            img.thumbnail((max_size, max_size))
            buf = io.BytesIO()
            img.save(buf, format="JPEG", quality=78)
            return base64.b64encode(buf.getvalue()).decode("ascii")
    except Exception:
        return None


async def try_fetch_video_thumbnail_b64(client: TelegramClient, telegram_chat_id: int, message_id: int) -> str | None:
    """
    Best-effort: Telegram generates a thumbnail server-side for video
    attachments. If one is available on the just-sent message, download it.
    Returns None (never raises) if unavailable — the UI falls back to an icon.
    """
    import io
    import base64

    try:
        entity = await client.get_entity(telegram_chat_id)
        message = await client.get_messages(entity, ids=message_id)
        if not message or not message.media:
            return None
        buf = io.BytesIO()
        result = await client.download_media(message, file=buf, thumb=-1)
        if not result:
            return None
        return base64.b64encode(buf.getvalue()).decode("ascii")
    except Exception:
        return None


async def delete_file_message(client: TelegramClient, telegram_chat_id: int, message_id: int):
    try:
        entity = await client.get_entity(telegram_chat_id)
        await client.delete_messages(entity, [message_id])
    except Exception as exc:
        raise _friendly_error(exc)
