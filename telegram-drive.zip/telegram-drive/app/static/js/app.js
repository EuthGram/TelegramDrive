// Shared behaviors used on every page.
document.addEventListener('click', (e) => {
  const menu = document.getElementById('account-menu');
  if (menu && menu.classList.contains('open') && !e.target.closest('.account-chip')) {
    menu.classList.remove('open');
  }
  document.querySelectorAll('.file-menu.open').forEach((m) => {
    if (!e.target.closest('.file-card')) m.classList.remove('open');
  });
});

function closeModal(id) {
  const el = document.getElementById(id);
  if (el) el.classList.remove('open');
}
