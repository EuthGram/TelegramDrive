"""
Application configuration.
All secrets are loaded from environment variables (.env file).
NEVER hardcode real credentials here.
"""
import os
import base64
import hashlib
from dotenv import load_dotenv

load_dotenv()


def _require(name: str, default: str | None = None) -> str:
    val = os.getenv(name, default)
    if val is None or val == "":
        raise RuntimeError(
            f"Missing required environment variable: {name}. "
            f"Copy .env.example to .env and fill it in."
        )
    return val


class Settings:
    # Core secret used for session signing, CSRF tokens, and (via KDF) file encryption.
    SECRET_KEY: str = _require("SECRET_KEY", "change-me-please-in-.env")

    # Database
    DATABASE_URL: str = os.getenv("DATABASE_URL", "sqlite:///./telegram_drive.db")

    # Default Telegram API credentials (optional). If not set, users must supply
    # their own API ID / API Hash on the setup page (recommended).
    DEFAULT_TELEGRAM_API_ID: str | None = os.getenv("TELEGRAM_API_ID") or None
    DEFAULT_TELEGRAM_API_HASH: str | None = os.getenv("TELEGRAM_API_HASH") or None

    # Uploads
    MAX_UPLOAD_SIZE_MB: int = int(os.getenv("MAX_UPLOAD_SIZE_MB", "2000"))
    TEMP_UPLOAD_DIR: str = os.getenv("TEMP_UPLOAD_DIR", "./tmp_uploads")

    # Session cookie
    SESSION_COOKIE_NAME: str = "td_session"
    SESSION_MAX_AGE: int = 60 * 60 * 24 * 14  # 14 days

    # Environment
    ENV: str = os.getenv("ENV", "development")
    DEBUG: bool = ENV != "production"

    @property
    def fernet_key(self) -> bytes:
        """
        Derive a 32-byte urlsafe base64 key for Fernet symmetric encryption
        from SECRET_KEY, so we don't need a second secret just for this.
        Used to encrypt Telegram API Hash / StringSession before storing in DB.
        """
        digest = hashlib.sha256(self.SECRET_KEY.encode("utf-8")).digest()
        return base64.urlsafe_b64encode(digest)


settings = Settings()
