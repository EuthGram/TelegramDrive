from fastapi import APIRouter, Request, Depends, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy.orm import Session

from app.database import get_db
from app.auth import (
    create_user, authenticate_user, login_user, logout_user,
    get_current_user_optional, get_or_create_csrf, require_csrf,
)
from app.security import login_rate_limiter
from app.main_templates import templates

router = APIRouter()


@router.get("/register", response_class=HTMLResponse)
async def register_page(request: Request, db: Session = Depends(get_db)):
    if get_current_user_optional(request, db):
        return RedirectResponse("/", status_code=303)
    return templates.TemplateResponse("register.html", {
        "request": request, "csrf_token": get_or_create_csrf(request), "error": None,
    })


@router.post("/register", response_class=HTMLResponse)
async def register_submit(
    request: Request,
    username: str = Form(...),
    password: str = Form(...),
    confirm_password: str = Form(...),
    csrf_token: str = Form(...),
    db: Session = Depends(get_db),
):
    require_csrf(request, csrf_token)
    error = None
    username = username.strip()

    if len(username) < 3:
        error = "Username must be at least 3 characters."
    elif len(password) < 8:
        error = "Password must be at least 8 characters."
    elif password != confirm_password:
        error = "Passwords do not match."

    if not error:
        try:
            user = create_user(db, username, password)
            login_user(request, user)
            return RedirectResponse("/", status_code=303)
        except ValueError as e:
            error = str(e)

    return templates.TemplateResponse("register.html", {
        "request": request, "csrf_token": get_or_create_csrf(request), "error": error,
    })


@router.get("/login", response_class=HTMLResponse)
async def login_page(request: Request, db: Session = Depends(get_db)):
    if get_current_user_optional(request, db):
        return RedirectResponse("/", status_code=303)
    return templates.TemplateResponse("login.html", {
        "request": request, "csrf_token": get_or_create_csrf(request), "error": None,
    })


@router.post("/login", response_class=HTMLResponse)
async def login_submit(
    request: Request,
    username: str = Form(...),
    password: str = Form(...),
    csrf_token: str = Form(...),
    db: Session = Depends(get_db),
):
    require_csrf(request, csrf_token)
    client_ip = request.client.host if request.client else "unknown"
    rl_key = f"{client_ip}:{username.strip().lower()}"

    if not login_rate_limiter.allow(rl_key):
        wait = login_rate_limiter.seconds_until_retry(rl_key)
        return templates.TemplateResponse("login.html", {
            "request": request, "csrf_token": get_or_create_csrf(request),
            "error": f"Too many login attempts. Try again in {wait} seconds.",
        })

    user = authenticate_user(db, username.strip(), password)
    if not user:
        return templates.TemplateResponse("login.html", {
            "request": request, "csrf_token": get_or_create_csrf(request),
            "error": "Invalid username or password.",
        })

    login_user(request, user)
    return RedirectResponse("/", status_code=303)


@router.get("/logout")
async def logout(request: Request):
    logout_user(request)
    return RedirectResponse("/login", status_code=303)
