(function () {
  const root = document.getElementById('app-root');
  const csrfToken = root.dataset.csrf;
  const isConnected = root.dataset.connected === '1';

  const state = {
    view: root.dataset.initialView === 'trash' ? 'trash' : 'drive',
    folderId: null,
    folderStack: [], // [{id, name}]
    category: null,
    storageId: null,
    search: '',
    sort: 'date_desc',
    folders: [],
  };

  const els = {
    folderGrid: document.getElementById('folder-grid'),
    fileGrid: document.getElementById('file-grid'),
    foldersSection: document.getElementById('folders-section'),
    emptyState: document.getElementById('empty-state'),
    emptyMsg: document.getElementById('empty-state-msg'),
    viewTitle: document.getElementById('view-title'),
    viewSubtitle: document.getElementById('view-subtitle'),
    filesSectionTitle: document.getElementById('files-section-title'),
    breadcrumb: document.getElementById('breadcrumb'),
    searchInput: document.getElementById('search-input'),
    sortSelect: document.getElementById('sort-select'),
    fileInput: document.getElementById('file-input'),
    dropzone: document.getElementById('dropzone-overlay'),
  };

  const CATEGORY_ICON = {
    image: 'bi-file-image', video: 'bi-file-play', document: 'bi-file-earmark-text',
    audio: 'bi-file-music', other: 'bi-file-earmark',
  };

  function fmtBytes(bytes) {
    if (!bytes) return '0 B';
    const units = ['B', 'KB', 'MB', 'GB', 'TB'];
    let i = 0, v = bytes;
    while (v >= 1024 && i < units.length - 1) { v /= 1024; i++; }
    return `${v.toFixed(v < 10 && i > 0 ? 1 : 0)} ${units[i]}`;
  }
  function fmtDate(iso) {
    if (!iso) return '';
    const d = new Date(iso);
    const today = new Date();
    const isToday = d.toDateString() === today.toDateString();
    if (isToday) return 'Today, ' + d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    return d.toLocaleDateString();
  }

  async function api(url, opts = {}) {
    const res = await fetch(url, opts);
    let data = null;
    try { data = await res.json(); } catch (e) { /* non-json (e.g. file download) */ }
    if (!res.ok && data && data.error) throw new Error(data.error);
    return data;
  }

  function formData(obj) {
    const fd = new FormData();
    Object.entries(obj).forEach(([k, v]) => { if (v !== null && v !== undefined) fd.append(k, v); });
    fd.append('csrf_token', csrfToken);
    return fd;
  }

  // ------------------------------------------------------------------
  // Loading / rendering
  // ------------------------------------------------------------------
  async function loadSummary() {
    try {
      const s = await api('/api/dashboard-summary');
      document.getElementById('stat-storage').textContent = fmtBytes(s.total_size_bytes);
      document.getElementById('stat-files').textContent = s.file_count;
      document.getElementById('stat-folders').textContent = s.folder_count;
      document.getElementById('stat-locations').textContent = s.storage_count;
      const label = document.getElementById('storage-used-label');
      const bar = document.getElementById('storage-used-bar');
      const countEl = document.getElementById('storage-file-count');
      if (label) label.textContent = fmtBytes(s.total_size_bytes);
      if (countEl) countEl.textContent = `${s.file_count} files`;
      if (bar) bar.style.width = Math.min(100, Math.max(4, s.file_count > 0 ? 30 : 4)) + '%';
    } catch (e) { /* ignore */ }
  }

  async function loadFolders() {
    state.folders = await api('/api/folders');
    renderFolders();
    populateMoveSelect();
  }

  function renderFolders() {
    const showFolders = state.view === 'drive' && !state.search && !state.category && !state.storageId;
    els.foldersSection.style.display = showFolders ? 'block' : 'none';
    if (!showFolders) return;

    const children = state.folders.filter((f) => f.parent_id === state.folderId);
    els.folderGrid.innerHTML = '';
    children.forEach((f) => {
      const card = document.createElement('div');
      card.className = 'folder-card';
      card.innerHTML = `<i class="bi bi-folder-fill"></i><span class="name">${escapeHtml(f.name)}</span>`;
      card.onclick = (e) => { openFolder(f); };
      card.oncontextmenu = (e) => { e.preventDefault(); folderContextMenu(f); };
      card.addEventListener('dblclick', () => folderContextMenu(f));
      els.folderGrid.appendChild(card);
    });
  }

  function folderContextMenu(f) {
    const action = prompt(`Folder: ${f.name}\nType "rename" or "delete"`, '');
    if (action === 'rename') {
      const name = prompt('New folder name', f.name);
      if (name) api('/api/folders/rename', { method: 'POST', body: formData({ folder_id: f.id, new_name: name }) }).then(loadFolders);
    } else if (action === 'delete') {
      if (confirm(`Delete folder "${f.name}"? Files inside will move to My Drive.`)) {
        api('/api/folders/delete', { method: 'POST', body: formData({ folder_id: f.id }) }).then(() => { loadFolders(); loadFiles(); });
      }
    }
  }

  function openFolder(f) {
    state.folderStack.push({ id: f.id, name: f.name });
    state.folderId = f.id;
    state.view = 'drive';
    state.category = null;
    state.storageId = null;
    refreshAll();
  }

  function goToBreadcrumb(index) {
    if (index === -1) { state.folderStack = []; state.folderId = null; }
    else { state.folderStack = state.folderStack.slice(0, index + 1); state.folderId = state.folderStack[index].id; }
    refreshAll();
  }

  function renderBreadcrumb() {
    if (state.view !== 'drive' || state.folderStack.length === 0) { els.breadcrumb.innerHTML = ''; return; }
    let html = `<a href="#" onclick="event.preventDefault();window.__td.goToBreadcrumb(-1)">My Drive</a>`;
    state.folderStack.forEach((f, i) => {
      html += ` / <a href="#" onclick="event.preventDefault();window.__td.goToBreadcrumb(${i})">${escapeHtml(f.name)}</a>`;
    });
    els.breadcrumb.innerHTML = html;
  }

  async function loadFiles() {
    const params = new URLSearchParams();
    params.set('sort', state.sort);

    if (state.view === 'trash') {
      params.set('trashed', 'true');
    } else if (state.view === 'recent') {
      params.set('all_folders', 'true');
    } else if (state.category) {
      params.set('category', state.category);
      params.set('all_folders', 'true');
    } else if (state.storageId) {
      params.set('storage_id', state.storageId);
      params.set('all_folders', 'true');
    } else if (state.folderId !== null) {
      params.set('folder_id', state.folderId);
    }
    if (state.search) { params.set('q', state.search); params.set('all_folders', 'true'); }

    let files = await api('/api/files?' + params.toString());
    if (state.view === 'recent') files = files.slice(0, 30);
    renderFiles(files);
  }

  function renderFiles(files) {
    els.fileGrid.innerHTML = '';
    const noFolders = !(state.view === 'drive' && !state.search);
    const totalEmpty = files.length === 0 && (noFolders || state.folders.filter(f => f.parent_id === state.folderId).length === 0);

    els.emptyState.style.display = totalEmpty ? 'block' : 'none';
    els.emptyMsg.textContent = state.view === 'trash' ? 'Trash is empty' : 'Upload your first file to Telegram Drive';
    els.fileGrid.style.display = files.length ? 'grid' : 'none';

    files.forEach((f) => els.fileGrid.appendChild(renderFileCard(f)));
  }

  function renderFileCard(f) {
    const card = document.createElement('div');
    card.className = 'file-card';
    const icon = CATEGORY_ICON[f.category] || CATEGORY_ICON.other;
    const thumbInner = f.has_thumbnail
      ? `<img src="/files/thumbnail/${f.id}" alt="" onerror="this.remove()"><i class="bi ${icon}" style="display:none"></i>`
      : `<i class="bi ${icon}"></i>`;
    card.innerHTML = `
      <div class="thumb">${thumbInner}</div>
      <div class="fname" title="${escapeHtml(f.name)}">${escapeHtml(f.name)}</div>
      <div class="fmeta">${fmtBytes(f.size)} &middot; ${fmtDate(f.uploaded_at)}</div>
      <button class="fmenu-btn" title="More"><i class="bi bi-three-dots-vertical"></i></button>
      <div class="file-menu"></div>
    `;
    const menu = card.querySelector('.file-menu');
    const btn = card.querySelector('.fmenu-btn');
    btn.onclick = (e) => {
      e.stopPropagation();
      document.querySelectorAll('.file-menu.open').forEach((m) => { if (m !== menu) m.classList.remove('open'); });
      menu.classList.toggle('open');
    };

    const actions = [];
    if (!f.is_trashed) {
      actions.push(['bi-download', 'Download', () => downloadFile(f)]);
      actions.push(['bi-pencil', 'Rename', () => openRename('file', f.id, f.name)]);
      actions.push(['bi-folder-symlink', 'Move', () => openMove(f.id)]);
      actions.push(['bi-link-45deg', 'Share / Copy Link', () => openShareModal(f)]);
      actions.push(['bi-trash3', 'Move to Trash', () => trashFile(f.id)]);
    } else {
      actions.push(['bi-arrow-counterclockwise', 'Restore', () => restoreFile(f.id)]);
      actions.push(['bi-x-octagon', 'Delete Permanently', () => deletePermanent(f.id)]);
    }
    actions.forEach(([icon, label, fn]) => {
      const b = document.createElement('button');
      b.innerHTML = `<i class="bi ${icon}"></i> ${label}`;
      b.onclick = (e) => { e.stopPropagation(); menu.classList.remove('open'); fn(); };
      menu.appendChild(b);
    });
    return card;
  }

  function escapeHtml(s) {
    const d = document.createElement('div'); d.textContent = s ?? ''; return d.innerHTML;
  }

  // ------------------------------------------------------------------
  // File actions
  // ------------------------------------------------------------------
  function downloadFile(f) { window.location = `/files/download/${f.id}`; }

  function trashFile(id) {
    api('/api/files/trash', { method: 'POST', body: formData({ file_id: id }) }).then(() => { loadFiles(); loadSummary(); });
  }
  function restoreFile(id) {
    api('/api/files/restore', { method: 'POST', body: formData({ file_id: id }) }).then(() => { loadFiles(); loadSummary(); });
  }
  function deletePermanent(id) {
    if (!confirm('Permanently delete this file from Telegram? This cannot be undone.')) return;
    api('/api/files/delete-permanent', { method: 'POST', body: formData({ file_id: id }) })
      .then(() => { loadFiles(); loadSummary(); })
      .catch((e) => alert(e.message));
  }

  // ------------------------------------------------------------------
  // Modals: new folder / rename / move
  // ------------------------------------------------------------------
  window.openNewFolderModal = () => {
    document.getElementById('new-folder-name').value = '';
    document.getElementById('modal-new-folder').classList.add('open');
  };
  window.submitNewFolder = () => {
    const name = document.getElementById('new-folder-name').value.trim();
    if (!name) return;
    api('/api/folders/create', { method: 'POST', body: formData({ name, parent_id: state.folderId }) })
      .then(() => { closeModal('modal-new-folder'); loadFolders(); });
  };

  let renameCtx = null;
  window.openRename = (type, id, currentName) => {
    renameCtx = { type, id };
    document.getElementById('rename-modal-title').textContent = type === 'folder' ? 'Rename folder' : 'Rename file';
    document.getElementById('rename-input').value = currentName;
    document.getElementById('modal-rename').classList.add('open');
  };
  window.submitRename = () => {
    const newName = document.getElementById('rename-input').value.trim();
    if (!newName || !renameCtx) return;
    const url = renameCtx.type === 'folder' ? '/api/folders/rename' : '/api/files/rename';
    const body = renameCtx.type === 'folder'
      ? formData({ folder_id: renameCtx.id, new_name: newName })
      : formData({ file_id: renameCtx.id, new_name: newName });
    api(url, { method: 'POST', body }).then(() => { closeModal('modal-rename'); loadFolders(); loadFiles(); });
  };

  let moveCtx = null;
  window.openMove = (fileId) => {
    moveCtx = fileId;
    document.getElementById('modal-move').classList.add('open');
  };
  function folderDepth(f, all, seen = new Set()) {
    // Guards against cycles just in case of bad data.
    let depth = 0, cur = f;
    while (cur && cur.parent_id !== null && !seen.has(cur.id)) {
      seen.add(cur.id);
      cur = all.find((x) => x.id === cur.parent_id);
      depth++;
    }
    return depth;
  }

  function populateMoveSelect() {
    const sel = document.getElementById('move-folder-select');
    if (!sel) return;
    sel.innerHTML = '<option value="">My Drive (root)</option>';
    // Sort so children render after their parents, with indentation showing nesting depth.
    const byDepth = state.folders
      .map((f) => ({ f, depth: folderDepth(f, state.folders) }))
      .sort((a, b) => a.depth - b.depth);
    byDepth.forEach(({ f, depth }) => {
      const opt = document.createElement('option');
      opt.value = f.id;
      opt.textContent = '\u00A0\u00A0'.repeat(depth) + (depth > 0 ? '↳ ' : '') + f.name;
      sel.appendChild(opt);
    });
  }
  window.submitMove = () => {
    const folderId = document.getElementById('move-folder-select').value || null;
    api('/api/files/move', { method: 'POST', body: formData({ file_id: moveCtx, folder_id: folderId }) })
      .then(() => { closeModal('modal-move'); loadFiles(); });
  };

  window.goToBreadcrumb = goToBreadcrumb;
  window.__td = { goToBreadcrumb };

  // ------------------------------------------------------------------
  // Share links
  // ------------------------------------------------------------------
  let shareCtx = null;
  window.openShareModal = (f) => {
    shareCtx = f.id;
    document.getElementById('share-result').style.display = 'none';
    document.getElementById('share-link-input').value = '';
    document.getElementById('share-expiry').value = '7d';
    document.getElementById('modal-share').classList.add('open');
  };
  window.submitCreateShare = () => {
    const expires_in = document.getElementById('share-expiry').value;
    api('/api/files/share', { method: 'POST', body: formData({ file_id: shareCtx, expires_in }) })
      .then((res) => {
        document.getElementById('share-link-input').value = res.url;
        document.getElementById('share-result').style.display = 'block';
      })
      .catch((e) => alert(e.message));
  };
  window.copyShareLink = () => {
    const input = document.getElementById('share-link-input');
    input.select();
    navigator.clipboard?.writeText(input.value).catch(() => document.execCommand('copy'));
  };

  // ------------------------------------------------------------------
  // Navigation (sidebar)
  // ------------------------------------------------------------------
  document.querySelectorAll('.nav-item[data-filter]').forEach((el) => {
    el.addEventListener('click', () => {
      const filter = el.dataset.filter;
      state.folderStack = []; state.folderId = null; state.storageId = null;
      if (filter === 'recent') { state.view = 'recent'; state.category = null; }
      else { state.view = 'drive'; state.category = filter; }
      setActiveNav(el);
      refreshAll();
    });
  });
  document.querySelectorAll('.nav-item[data-storage-filter]').forEach((el) => {
    el.addEventListener('click', () => {
      state.folderStack = []; state.folderId = null; state.category = null;
      state.storageId = el.dataset.storageFilter;
      state.view = 'drive';
      setActiveNav(el);
      refreshAll();
    });
  });
  function setActiveNav(activeEl) {
    document.querySelectorAll('.nav-item').forEach((n) => n.classList.remove('active'));
    activeEl.classList.add('active');
  }

  els.searchInput.addEventListener('input', debounce(() => {
    state.search = els.searchInput.value.trim();
    loadFiles();
  }, 350));
  els.sortSelect.addEventListener('change', () => { state.sort = els.sortSelect.value; loadFiles(); });

  function debounce(fn, ms) {
    let t; return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
  }

  function refreshAll() {
    const titles = {
      drive: 'My Drive', recent: 'Recent', trash: 'Trash',
      image: 'Images', video: 'Videos', document: 'Documents', audio: 'Audio',
    };
    const key = state.category || state.view;
    els.viewTitle.textContent = state.folderStack.length
      ? state.folderStack[state.folderStack.length - 1].name
      : (titles[key] || 'My Drive');
    els.viewSubtitle.textContent = state.view === 'trash'
      ? 'Files here can be restored or permanently deleted'
      : 'All your files, backed by your own Telegram account';
    els.filesSectionTitle.textContent = state.view === 'trash' ? 'Trashed files' : 'Files';
    renderBreadcrumb();
    renderFolders();
    loadFiles();
  }

  // ------------------------------------------------------------------
  // Upload: file picker + drag & drop, with progress
  // ------------------------------------------------------------------
  els.fileInput.addEventListener('change', () => {
    if (els.fileInput.files.length) uploadFiles(Array.from(els.fileInput.files));
    els.fileInput.value = '';
  });

  ['dragenter', 'dragover'].forEach((evt) => {
    document.addEventListener(evt, (e) => {
      if (!isConnected) return;
      e.preventDefault();
      els.dropzone.classList.add('active');
    });
  });
  ['dragleave', 'drop'].forEach((evt) => {
    document.addEventListener(evt, (e) => {
      e.preventDefault();
      if (evt === 'drop') {
        els.dropzone.classList.remove('active');
        if (!isConnected) { alert('Connect Telegram before uploading files.'); return; }
        const files = Array.from(e.dataTransfer.files || []);
        if (files.length) uploadFiles(files);
      } else if (e.target === document || e.target === els.dropzone) {
        els.dropzone.classList.remove('active');
      }
    });
  });

  function uploadFiles(files) {
    document.getElementById('modal-progress').classList.add('open');
    const list = document.getElementById('progress-list');
    list.innerHTML = '';
    files.forEach((file) => {
      const row = document.createElement('div');
      row.className = 'progress-item';
      row.innerHTML = `<div>${escapeHtml(file.name)} <span class="pct">0%</span></div><div class="bar"><div class="bar-fill"></div></div>`;
      list.appendChild(row);
      uploadOne(file, row);
    });
  }

  function uploadOne(file, row) {
    const xhr = new XMLHttpRequest();
    const fd = new FormData();
    fd.append('file', file);
    fd.append('csrf_token', csrfToken);
    if (state.folderId !== null && state.view === 'drive') fd.append('folder_id', state.folderId);
    if (state.storageId) fd.append('storage_id', state.storageId);

    xhr.upload.onprogress = (e) => {
      if (!e.lengthComputable) return;
      const pct = Math.round((e.loaded / e.total) * 100);
      row.querySelector('.bar-fill').style.width = pct + '%';
      row.querySelector('.pct').textContent = pct + '%';
    };
    xhr.onload = () => {
      let data = {};
      try { data = JSON.parse(xhr.responseText); } catch (e) {}
      if (xhr.status >= 200 && xhr.status < 300 && !data.error) {
        row.classList.add('done');
        row.querySelector('.pct').textContent = 'Done';
        loadFiles(); loadSummary();
      } else {
        row.classList.add('error');
        row.querySelector('.pct').textContent = data.error || 'Failed';
      }
    };
    xhr.onerror = () => { row.classList.add('error'); row.querySelector('.pct').textContent = 'Network error'; };
    xhr.open('POST', '/files/upload');
    xhr.send(fd);
  }

  // ------------------------------------------------------------------
  // Init
  // ------------------------------------------------------------------
  loadSummary();
  loadFolders().then(() => renderFolders());
  loadFiles();
})();
