"""
Security helpers.

- Password hashing (bcrypt via passlib)
- Symmetric encryption for Telegram credentials at rest (Fernet)
- CSRF token generation / verification
- A lightweight in-memory rate limiter for auth endpoints
"""
import time
import secrets
from collections import defaultdict, deque

from passlib.context import CryptContext
from cryptography.fernet import Fernet, InvalidToken

from app.config import settings

# ---------------------------------------------------------------------------
# Password hashing
# ---------------------------------------------------------------------------
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def hash_password(password: str) -> str:
    return pwd_context.hash(password)


def verify_password(password: str, password_hash: str) -> bool:
    try:
        return pwd_context.verify(password, password_hash)
    except Exception:
        return False


# ---------------------------------------------------------------------------
# Encryption at rest for Telegram API Hash / StringSession
# ---------------------------------------------------------------------------
_fernet = Fernet(settings.fernet_key)


def encrypt_secret(plaintext: str) -> str:
    if plaintext is None:
        return None
    return _fernet.encrypt(plaintext.encode("utf-8")).decode("utf-8")


def decrypt_secret(ciphertext: str) -> str:
    if ciphertext is None:
        return None
    try:
        return _fernet.decrypt(ciphertext.encode("utf-8")).decode("utf-8")
    except InvalidToken:
        raise ValueError("Unable to decrypt stored credential (invalid key or corrupted data).")


# ---------------------------------------------------------------------------
# CSRF protection (double-submit token stored in the session cookie)
# ---------------------------------------------------------------------------
def generate_csrf_token() -> str:
    return secrets.token_urlsafe(32)


def verify_csrf(session_token: str | None, submitted_token: str | None) -> bool:
    if not session_token or not submitted_token:
        return False
    return secrets.compare_digest(session_token, submitted_token)


# ---------------------------------------------------------------------------
# Simple in-memory rate limiter (per key, e.g. IP or IP+username)
# Good enough for a single-process MVP deployment. For multi-worker
# production deployments behind a load balancer, replace with a
# Redis-backed limiter.
# ---------------------------------------------------------------------------
class RateLimiter:
    def __init__(self, max_attempts: int, window_seconds: int):
        self.max_attempts = max_attempts
        self.window_seconds = window_seconds
        self._hits: dict[str, deque] = defaultdict(deque)

    def allow(self, key: str) -> bool:
        now = time.time()
        q = self._hits[key]
        while q and now - q[0] > self.window_seconds:
            q.popleft()
        if len(q) >= self.max_attempts:
            return False
        q.append(now)
        return True

    def seconds_until_retry(self, key: str) -> int:
        q = self._hits.get(key)
        if not q:
            return 0
        return max(0, int(self.window_seconds - (time.time() - q[0])))


login_rate_limiter = RateLimiter(max_attempts=8, window_seconds=300)
telegram_auth_rate_limiter = RateLimiter(max_attempts=10, window_seconds=600)
