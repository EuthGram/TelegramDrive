import os
import uuid
import secrets
from datetime import datetime, timedelta

from fastapi import APIRouter, Request, Depends, Form, UploadFile, File as FileParam
from fastapi.responses import JSONResponse, FileResponse, Response
from sqlalchemy.orm import Session

from app.database import get_db
from app.auth import get_current_user, require_csrf
from app.models import FileRecord, StorageLocation, TelegramAccount, Folder, ShareLink
from app.config import settings
from app import telegram_service as tg
from app.telegram_service import (
    TelegramServiceError, ConnectedClient, guess_category,
    generate_image_thumbnail_b64, try_fetch_video_thumbnail_b64,
)

router = APIRouter()
public_router = APIRouter()  # unauthenticated routes (shared links)

os.makedirs(settings.TEMP_UPLOAD_DIR, exist_ok=True)


def _serialize(f: FileRecord) -> dict:
    return {
        "id": f.id,
        "name": f.original_filename,
        "size": f.size,
        "mime_type": f.mime_type,
        "category": f.file_category,
        "folder_id": f.folder_id,
        "storage_id": f.storage_id,
        "uploaded_at": f.uploaded_at.isoformat() if f.uploaded_at else None,
        "is_trashed": f.is_trashed,
        "has_thumbnail": bool(f.thumbnail_data),
    }


@router.get("/api/files")
async def list_files(
    folder_id: int | None = None,
    storage_id: int | None = None,
    q: str | None = None,
    category: str | None = None,
    trashed: bool = False,
    all_folders: bool = False,
    sort: str = "date_desc",
    user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    query = db.query(FileRecord).filter(
        FileRecord.user_id == user.id, FileRecord.is_trashed == trashed
    )
    if folder_id is not None:
        query = query.filter(FileRecord.folder_id == folder_id)
    elif not all_folders and not q and not category and not storage_id and not trashed:
        query = query.filter(FileRecord.folder_id.is_(None))
    if storage_id is not None:
        query = query.filter(FileRecord.storage_id == storage_id)
    if q:
        like = f"%{q.strip()}%"
        query = query.filter(FileRecord.original_filename.ilike(like))
    if category:
        query = query.filter(FileRecord.file_category == category)

    if sort == "name_asc":
        query = query.order_by(FileRecord.original_filename.asc())
    elif sort == "name_desc":
        query = query.order_by(FileRecord.original_filename.desc())
    elif sort == "size_desc":
        query = query.order_by(FileRecord.size.desc())
    elif sort == "date_asc":
        query = query.order_by(FileRecord.uploaded_at.asc())
    else:
        query = query.order_by(FileRecord.uploaded_at.desc())

    files = query.all()
    return [_serialize(f) for f in files]


@router.get("/api/dashboard-summary")
async def dashboard_summary(user=Depends(get_current_user), db: Session = Depends(get_db)):
    files = db.query(FileRecord).filter(
        FileRecord.user_id == user.id, FileRecord.is_trashed == False  # noqa: E712
    ).all()
    total_size = sum(f.size or 0 for f in files)
    folder_count = db.query(Folder).filter(Folder.user_id == user.id).count()
    storage_count = db.query(StorageLocation).filter(StorageLocation.user_id == user.id).count()
    return {
        "file_count": len(files),
        "folder_count": folder_count,
        "storage_count": storage_count,
        "total_size_bytes": total_size,
    }


@router.post("/files/upload")
async def upload_file(
    request: Request,
    file: UploadFile = FileParam(...),
    folder_id: int | None = Form(None),
    storage_id: int | None = Form(None),
    csrf_token: str = Form(...),
    user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    require_csrf(request, csrf_token)

    account = db.query(TelegramAccount).filter(TelegramAccount.user_id == user.id).first()
    if not account or not account.is_connected:
        return JSONResponse({"error": "Connect Telegram before uploading files."}, status_code=400)

    if storage_id:
        storage = db.query(StorageLocation).filter(
            StorageLocation.id == storage_id, StorageLocation.user_id == user.id
        ).first()
    else:
        storage = db.query(StorageLocation).filter(
            StorageLocation.user_id == user.id, StorageLocation.is_default == True  # noqa: E712
        ).first()

    if not storage:
        return JSONResponse(
            {"error": "No storage destination configured. Create one in Settings first."},
            status_code=400,
        )

    max_bytes = settings.MAX_UPLOAD_SIZE_MB * 1024 * 1024
    temp_name = f"{uuid.uuid4().hex}_{file.filename}"
    temp_path = os.path.join(settings.TEMP_UPLOAD_DIR, temp_name)

    size = 0
    try:
        with open(temp_path, "wb") as out:
            while chunk := await file.read(1024 * 1024):
                size += len(chunk)
                if size > max_bytes:
                    raise ValueError(f"File exceeds the {settings.MAX_UPLOAD_SIZE_MB}MB limit.")
                out.write(chunk)
    except ValueError as e:
        if os.path.exists(temp_path):
            os.remove(temp_path)
        return JSONResponse({"error": str(e)}, status_code=400)

    category = guess_category(file.filename, file.content_type)
    thumbnail_b64 = None

    try:
        async with ConnectedClient(account) as client:
            message_id = await tg.upload_file_to_chat(
                client, storage.telegram_chat_id, temp_path, file.filename
            )
            if category == "image":
                thumbnail_b64 = generate_image_thumbnail_b64(temp_path)
            elif category == "video":
                thumbnail_b64 = await try_fetch_video_thumbnail_b64(
                    client, storage.telegram_chat_id, message_id
                )
    except TelegramServiceError as e:
        return JSONResponse({"error": e.message}, status_code=502)
    finally:
        if os.path.exists(temp_path):
            os.remove(temp_path)

    record = FileRecord(
        user_id=user.id,
        folder_id=folder_id or None,
        storage_id=storage.id,
        original_filename=file.filename,
        size=size,
        mime_type=file.content_type,
        file_category=category,
        telegram_chat_id=storage.telegram_chat_id,
        telegram_message_id=message_id,
        thumbnail_data=thumbnail_b64,
        thumbnail_available=bool(thumbnail_b64),
    )
    db.add(record)
    db.commit()
    db.refresh(record)
    return _serialize(record)


@router.get("/files/thumbnail/{file_id}")
async def get_thumbnail(file_id: int, user=Depends(get_current_user), db: Session = Depends(get_db)):
    record = db.query(FileRecord).filter(FileRecord.id == file_id, FileRecord.user_id == user.id).first()
    if not record or not record.thumbnail_data:
        return JSONResponse({"error": "No thumbnail available."}, status_code=404)
    import base64
    raw = base64.b64decode(record.thumbnail_data)
    return Response(content=raw, media_type="image/jpeg")


@router.get("/files/download/{file_id}")
async def download_file(file_id: int, user=Depends(get_current_user), db: Session = Depends(get_db)):
    record = db.query(FileRecord).filter(FileRecord.id == file_id, FileRecord.user_id == user.id).first()
    if not record:
        return JSONResponse({"error": "File not found."}, status_code=404)

    account = db.query(TelegramAccount).filter(TelegramAccount.user_id == user.id).first()
    if not account or not account.is_connected:
        return JSONResponse({"error": "Telegram is not connected."}, status_code=400)

    dest_dir = os.path.join(settings.TEMP_UPLOAD_DIR, "downloads")
    os.makedirs(dest_dir, exist_ok=True)
    dest_path = os.path.join(dest_dir, f"{uuid.uuid4().hex}_{record.original_filename}")

    try:
        async with ConnectedClient(account) as client:
            await tg.download_file_from_chat(
                client, record.telegram_chat_id, record.telegram_message_id, dest_path
            )
    except TelegramServiceError as e:
        return JSONResponse({"error": e.message}, status_code=502)

    return FileResponse(
        dest_path, filename=record.original_filename,
        media_type=record.mime_type or "application/octet-stream",
        background=_cleanup_after_send(dest_path),
    )


def _cleanup_after_send(path: str):
    from starlette.background import BackgroundTask

    def _remove():
        if os.path.exists(path):
            try:
                os.remove(path)
            except OSError:
                pass

    return BackgroundTask(_remove)


@router.post("/api/files/rename")
async def rename_file(
    request: Request,
    file_id: int = Form(...),
    new_name: str = Form(...),
    csrf_token: str = Form(...),
    user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    require_csrf(request, csrf_token)
    record = db.query(FileRecord).filter(FileRecord.id == file_id, FileRecord.user_id == user.id).first()
    if not record:
        return JSONResponse({"error": "File not found."}, status_code=404)
    record.original_filename = new_name.strip()
    db.commit()
    return _serialize(record)


@router.post("/api/files/move")
async def move_file(
    request: Request,
    file_id: int = Form(...),
    folder_id: int | None = Form(None),
    csrf_token: str = Form(...),
    user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    require_csrf(request, csrf_token)
    record = db.query(FileRecord).filter(FileRecord.id == file_id, FileRecord.user_id == user.id).first()
    if not record:
        return JSONResponse({"error": "File not found."}, status_code=404)
    record.folder_id = folder_id or None
    db.commit()
    return _serialize(record)


@router.post("/api/files/trash")
async def trash_file(
    request: Request,
    file_id: int = Form(...),
    csrf_token: str = Form(...),
    user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    require_csrf(request, csrf_token)
    record = db.query(FileRecord).filter(FileRecord.id == file_id, FileRecord.user_id == user.id).first()
    if not record:
        return JSONResponse({"error": "File not found."}, status_code=404)
    record.is_trashed = True
    db.commit()
    return {"ok": True}


@router.post("/api/files/restore")
async def restore_file(
    request: Request,
    file_id: int = Form(...),
    csrf_token: str = Form(...),
    user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    require_csrf(request, csrf_token)
    record = db.query(FileRecord).filter(FileRecord.id == file_id, FileRecord.user_id == user.id).first()
    if not record:
        return JSONResponse({"error": "File not found."}, status_code=404)
    record.is_trashed = False
    db.commit()
    return {"ok": True}


_EXPIRY_MAP = {
    "1d": timedelta(days=1),
    "7d": timedelta(days=7),
    "30d": timedelta(days=30),
    "never": None,
}


@router.post("/api/files/share")
async def create_share_link(
    request: Request,
    file_id: int = Form(...),
    expires_in: str = Form("7d"),
    csrf_token: str = Form(...),
    user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    require_csrf(request, csrf_token)
    record = db.query(FileRecord).filter(FileRecord.id == file_id, FileRecord.user_id == user.id).first()
    if not record:
        return JSONResponse({"error": "File not found."}, status_code=404)

    delta = _EXPIRY_MAP.get(expires_in, _EXPIRY_MAP["7d"])
    expires_at = (datetime.utcnow() + delta) if delta else None

    link = ShareLink(
        file_id=record.id, user_id=user.id,
        token=secrets.token_urlsafe(24), expires_at=expires_at,
    )
    db.add(link)
    db.commit()
    db.refresh(link)

    share_url = str(request.base_url).rstrip("/") + f"/s/{link.token}"
    return {
        "token": link.token, "url": share_url,
        "expires_at": link.expires_at.isoformat() if link.expires_at else None,
    }


@router.post("/api/files/share/revoke")
async def revoke_share_link(
    request: Request,
    token: str = Form(...),
    csrf_token: str = Form(...),
    user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    require_csrf(request, csrf_token)
    link = db.query(ShareLink).filter(ShareLink.token == token, ShareLink.user_id == user.id).first()
    if not link:
        return JSONResponse({"error": "Share link not found."}, status_code=404)
    link.is_revoked = True
    db.commit()
    return {"ok": True}


@router.get("/api/files/shares")
async def list_shares(file_id: int, user=Depends(get_current_user), db: Session = Depends(get_db)):
    links = db.query(ShareLink).filter(
        ShareLink.file_id == file_id, ShareLink.user_id == user.id, ShareLink.is_revoked == False  # noqa: E712
    ).order_by(ShareLink.created_at.desc()).all()
    out = []
    for l in links:
        if l.expires_at and l.expires_at < datetime.utcnow():
            continue
        out.append({
            "token": l.token,
            "expires_at": l.expires_at.isoformat() if l.expires_at else None,
            "download_count": l.download_count,
        })
    return out


@public_router.get("/s/{token}")
async def public_shared_download(token: str, db: Session = Depends(get_db)):
    """
    Public, unauthenticated download endpoint for a shared file.
    No website login required — access is controlled entirely by the
    unguessable token, expiry, and revocation state.
    """
    link = db.query(ShareLink).filter(ShareLink.token == token).first()
    if not link or link.is_revoked:
        return JSONResponse({"error": "This link is invalid or has been revoked."}, status_code=404)
    if link.expires_at and link.expires_at < datetime.utcnow():
        return JSONResponse({"error": "This link has expired."}, status_code=410)

    record = db.query(FileRecord).filter(FileRecord.id == link.file_id).first()
    if not record or record.is_trashed:
        return JSONResponse({"error": "This file is no longer available."}, status_code=404)

    account = db.query(TelegramAccount).filter(TelegramAccount.user_id == link.user_id).first()
    if not account or not account.is_connected:
        return JSONResponse({"error": "The file owner's Telegram is currently disconnected."}, status_code=503)

    dest_dir = os.path.join(settings.TEMP_UPLOAD_DIR, "shared")
    os.makedirs(dest_dir, exist_ok=True)
    dest_path = os.path.join(dest_dir, f"{uuid.uuid4().hex}_{record.original_filename}")

    try:
        async with ConnectedClient(account) as client:
            await tg.download_file_from_chat(
                client, record.telegram_chat_id, record.telegram_message_id, dest_path
            )
    except TelegramServiceError as e:
        return JSONResponse({"error": e.message}, status_code=502)

    link.download_count = (link.download_count or 0) + 1
    db.commit()

    return FileResponse(
        dest_path, filename=record.original_filename,
        media_type=record.mime_type or "application/octet-stream",
        background=_cleanup_after_send(dest_path),
    )


@router.post("/api/files/delete-permanent")
async def delete_file_permanent(
    request: Request,
    file_id: int = Form(...),
    csrf_token: str = Form(...),
    user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    require_csrf(request, csrf_token)
    record = db.query(FileRecord).filter(FileRecord.id == file_id, FileRecord.user_id == user.id).first()
    if not record:
        return JSONResponse({"error": "File not found."}, status_code=404)

    account = db.query(TelegramAccount).filter(TelegramAccount.user_id == user.id).first()
    if account and account.is_connected:
        try:
            async with ConnectedClient(account) as client:
                await tg.delete_file_message(client, record.telegram_chat_id, record.telegram_message_id)
        except TelegramServiceError as e:
            return JSONResponse({"error": e.message}, status_code=502)

    db.delete(record)
    db.commit()
    return {"ok": True}
