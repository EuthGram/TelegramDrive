from fastapi import APIRouter, Request, Depends, Form
from fastapi.responses import JSONResponse
from sqlalchemy.orm import Session

from app.database import get_db
from app.auth import get_current_user, require_csrf
from app.models import Folder, FileRecord

router = APIRouter()


@router.get("/api/folders")
async def list_folders(user=Depends(get_current_user), db: Session = Depends(get_db)):
    folders = db.query(Folder).filter(Folder.user_id == user.id).order_by(Folder.name).all()
    return [{"id": f.id, "name": f.name, "parent_id": f.parent_id} for f in folders]


@router.post("/api/folders/create")
async def create_folder(
    request: Request,
    name: str = Form(...),
    parent_id: int | None = Form(None),
    csrf_token: str = Form(...),
    user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    require_csrf(request, csrf_token)
    name = name.strip()
    if not name:
        return JSONResponse({"error": "Folder name cannot be empty."}, status_code=400)

    folder = Folder(user_id=user.id, name=name, parent_id=parent_id or None)
    db.add(folder)
    db.commit()
    return {"id": folder.id, "name": folder.name, "parent_id": folder.parent_id}


@router.post("/api/folders/rename")
async def rename_folder(
    request: Request,
    folder_id: int = Form(...),
    new_name: str = Form(...),
    csrf_token: str = Form(...),
    user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    require_csrf(request, csrf_token)
    folder = db.query(Folder).filter(Folder.id == folder_id, Folder.user_id == user.id).first()
    if not folder:
        return JSONResponse({"error": "Folder not found."}, status_code=404)
    folder.name = new_name.strip()
    db.commit()
    return {"ok": True}


@router.post("/api/folders/delete")
async def delete_folder(
    request: Request,
    folder_id: int = Form(...),
    csrf_token: str = Form(...),
    user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    require_csrf(request, csrf_token)
    folder = db.query(Folder).filter(Folder.id == folder_id, Folder.user_id == user.id).first()
    if not folder:
        return JSONResponse({"error": "Folder not found."}, status_code=404)

    # Move any files in this folder back to root instead of silently deleting them.
    db.query(FileRecord).filter(FileRecord.folder_id == folder_id).update({"folder_id": None})
    db.query(Folder).filter(Folder.parent_id == folder_id).update({"parent_id": None})
    db.delete(folder)
    db.commit()
    return {"ok": True}
