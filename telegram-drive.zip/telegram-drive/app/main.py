from fastapi import FastAPI, Request, Depends
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.sessions import SessionMiddleware
from sqlalchemy.orm import Session

from app.config import settings
from app.database import init_db, get_db
from app.main_templates import templates
from app.auth import get_current_user, get_current_user_optional, get_or_create_csrf
from app.models import TelegramAccount, StorageLocation, Folder

from app.routes import auth as auth_routes
from app.routes import telegram as telegram_routes
from app.routes import storage as storage_routes
from app.routes import folders as folder_routes
from app.routes import files as file_routes

app = FastAPI(title="Telegram Drive")

app.add_middleware(
    SessionMiddleware,
    secret_key=settings.SECRET_KEY,
    max_age=settings.SESSION_MAX_AGE,
    same_site="lax",
    https_only=(settings.ENV == "production"),
)

app.mount("/static", StaticFiles(directory="app/static"), name="static")

app.include_router(auth_routes.router)
app.include_router(telegram_routes.router)
app.include_router(storage_routes.router)
app.include_router(folder_routes.router)
app.include_router(file_routes.router)
app.include_router(file_routes.public_router)


@app.on_event("startup")
def on_startup():
    init_db()


@app.get("/", response_class=HTMLResponse)
async def dashboard(request: Request, db: Session = Depends(get_db)):
    user = get_current_user_optional(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)

    account = db.query(TelegramAccount).filter(TelegramAccount.user_id == user.id).first()
    folders = db.query(Folder).filter(Folder.user_id == user.id, Folder.parent_id.is_(None)).all()
    storage_locations = db.query(StorageLocation).filter(StorageLocation.user_id == user.id).all()

    return templates.TemplateResponse("dashboard.html", {
        "request": request,
        "user": user,
        "account": account,
        "folders": folders,
        "storage_locations": storage_locations,
        "csrf_token": get_or_create_csrf(request),
    })


@app.get("/trash", response_class=HTMLResponse)
async def trash_page(request: Request, user=Depends(get_current_user), db: Session = Depends(get_db)):
    return templates.TemplateResponse("dashboard.html", {
        "request": request,
        "user": user,
        "account": db.query(TelegramAccount).filter(TelegramAccount.user_id == user.id).first(),
        "folders": db.query(Folder).filter(Folder.user_id == user.id, Folder.parent_id.is_(None)).all(),
        "storage_locations": db.query(StorageLocation).filter(StorageLocation.user_id == user.id).all(),
        "csrf_token": get_or_create_csrf(request),
        "initial_view": "trash",
    })


@app.exception_handler(303)
async def redirect_handler(request: Request, exc):
    return RedirectResponse(exc.headers.get("Location", "/login"), status_code=303)
