from fastapi import APIRouter, Request, Depends, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy.orm import Session

from app.database import get_db
from app.auth import get_current_user, get_or_create_csrf, require_csrf
from app.main_templates import templates
from app.models import TelegramAccount
from app.security import encrypt_secret, telegram_auth_rate_limiter
from app.config import settings
from app import telegram_service as tg
from app.telegram_service import TelegramServiceError, TwoFactorRequired

router = APIRouter()


@router.get("/setup", response_class=HTMLResponse)
async def setup_page(request: Request, user=Depends(get_current_user), db: Session = Depends(get_db)):
    account = db.query(TelegramAccount).filter(TelegramAccount.user_id == user.id).first()
    return templates.TemplateResponse("setup_telegram.html", {
        "request": request,
        "user": user,
        "account": account,
        "csrf_token": get_or_create_csrf(request),
        "default_api_id": settings.DEFAULT_TELEGRAM_API_ID or "",
        "step": "start",
        "error": None,
        "login_token": None,
    })


@router.post("/setup/send-code", response_class=HTMLResponse)
async def send_code(
    request: Request,
    api_id: str = Form(...),
    api_hash: str = Form(...),
    phone: str = Form(...),
    csrf_token: str = Form(...),
    user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    require_csrf(request, csrf_token)
    client_ip = request.client.host if request.client else "unknown"
    if not telegram_auth_rate_limiter.allow(f"{client_ip}:{user.id}"):
        return templates.TemplateResponse("setup_telegram.html", {
            "request": request, "user": user, "account": None,
            "csrf_token": get_or_create_csrf(request), "step": "start",
            "error": "Too many attempts. Please wait a few minutes and try again.",
            "login_token": None, "default_api_id": api_id,
        })

    try:
        token = await tg.start_login(api_id.strip(), api_hash.strip(), phone.strip())
    except TelegramServiceError as e:
        return templates.TemplateResponse("setup_telegram.html", {
            "request": request, "user": user, "account": None,
            "csrf_token": get_or_create_csrf(request), "step": "start",
            "error": e.message, "login_token": None, "default_api_id": api_id,
        })

    request.session["pending_phone"] = phone.strip()
    return templates.TemplateResponse("setup_telegram.html", {
        "request": request, "user": user, "account": None,
        "csrf_token": get_or_create_csrf(request), "step": "code",
        "error": None, "login_token": token, "default_api_id": api_id,
    })


@router.post("/setup/verify-code", response_class=HTMLResponse)
async def verify_code(
    request: Request,
    login_token: str = Form(...),
    code: str = Form(...),
    csrf_token: str = Form(...),
    user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    require_csrf(request, csrf_token)
    try:
        result = await tg.submit_code(login_token, code.strip())
    except TwoFactorRequired:
        return templates.TemplateResponse("setup_telegram.html", {
            "request": request, "user": user, "account": None,
            "csrf_token": get_or_create_csrf(request), "step": "password",
            "error": None, "login_token": login_token, "default_api_id": "",
        })
    except TelegramServiceError as e:
        return templates.TemplateResponse("setup_telegram.html", {
            "request": request, "user": user, "account": None,
            "csrf_token": get_or_create_csrf(request), "step": "code",
            "error": e.message, "login_token": login_token, "default_api_id": "",
        })

    _persist_account(db, user.id, result)
    return RedirectResponse("/setup?connected=1", status_code=303)


@router.post("/setup/verify-password", response_class=HTMLResponse)
async def verify_password(
    request: Request,
    login_token: str = Form(...),
    password: str = Form(...),
    csrf_token: str = Form(...),
    user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    require_csrf(request, csrf_token)
    try:
        result = await tg.submit_password(login_token, password)
    except TelegramServiceError as e:
        return templates.TemplateResponse("setup_telegram.html", {
            "request": request, "user": user, "account": None,
            "csrf_token": get_or_create_csrf(request), "step": "password",
            "error": e.message, "login_token": login_token, "default_api_id": "",
        })

    _persist_account(db, user.id, result)
    return RedirectResponse("/setup?connected=1", status_code=303)


def _persist_account(db: Session, user_id: int, result: dict):
    account = db.query(TelegramAccount).filter(TelegramAccount.user_id == user_id).first()
    if not account:
        account = TelegramAccount(user_id=user_id)
        db.add(account)

    account.api_id = result["api_id"]
    account.api_hash_enc = encrypt_secret(result["api_hash"])
    account.session_enc = encrypt_secret(result["session_string"])
    account.phone = result["phone"]
    account.telegram_user_id = result["telegram_user_id"]
    account.telegram_first_name = result["first_name"]
    account.telegram_username = result["username"]
    account.is_connected = True
    db.commit()


@router.post("/setup/use-existing-session", response_class=HTMLResponse)
async def use_existing_session(
    request: Request,
    api_id: str = Form(...),
    api_hash: str = Form(...),
    session_string: str = Form(...),
    csrf_token: str = Form(...),
    user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Allow advanced users to import an existing Telethon StringSession directly."""
    require_csrf(request, csrf_token)
    from telethon import TelegramClient
    from telethon.sessions import StringSession

    error = None
    try:
        client = TelegramClient(StringSession(session_string.strip()), int(api_id), api_hash.strip())
        await client.connect()
        if not await client.is_user_authorized():
            error = "This StringSession is not authorized or has expired."
        else:
            me = await client.get_me()
            result = {
                "api_id": api_id.strip(), "api_hash": api_hash.strip(),
                "phone": getattr(me, "phone", None), "session_string": session_string.strip(),
                "telegram_user_id": me.id, "first_name": me.first_name, "username": me.username,
            }
            _persist_account(db, user.id, result)
        await client.disconnect()
    except Exception as e:
        error = f"Could not validate this session: {e}"

    if error:
        return templates.TemplateResponse("setup_telegram.html", {
            "request": request, "user": user, "account": None,
            "csrf_token": get_or_create_csrf(request), "step": "start",
            "error": error, "login_token": None, "default_api_id": api_id,
        })
    return RedirectResponse("/setup?connected=1", status_code=303)


@router.post("/setup/disconnect")
async def disconnect(
    request: Request,
    csrf_token: str = Form(...),
    user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    require_csrf(request, csrf_token)
    account = db.query(TelegramAccount).filter(TelegramAccount.user_id == user.id).first()
    if account:
        db.delete(account)
        db.commit()
    return RedirectResponse("/setup?disconnected=1", status_code=303)
