from datetime import datetime

from sqlalchemy import (
    Column, Integer, String, BigInteger, Boolean, DateTime, ForeignKey, Text
)
from sqlalchemy.orm import relationship

from app.database import Base


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True)
    username = Column(String(64), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    telegram_account = relationship(
        "TelegramAccount", back_populates="user", uselist=False,
        cascade="all, delete-orphan"
    )
    storage_locations = relationship(
        "StorageLocation", back_populates="user", cascade="all, delete-orphan"
    )
    folders = relationship("Folder", back_populates="user", cascade="all, delete-orphan")
    files = relationship("FileRecord", back_populates="user", cascade="all, delete-orphan")


class TelegramAccount(Base):
    """
    Stores the connected Telegram account for a user.
    api_hash_enc and session_enc are ALWAYS stored encrypted (Fernet).
    Never expose these fields to templates or JSON responses.
    """
    __tablename__ = "telegram_accounts"

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), unique=True, nullable=False)

    api_id = Column(String(32), nullable=False)
    api_hash_enc = Column(Text, nullable=False)
    session_enc = Column(Text, nullable=True)  # Telethon StringSession, encrypted
    phone = Column(String(32), nullable=True)

    telegram_user_id = Column(BigInteger, nullable=True)
    telegram_first_name = Column(String(128), nullable=True)
    telegram_username = Column(String(128), nullable=True)

    is_connected = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    user = relationship("User", back_populates="telegram_account")


class StorageLocation(Base):
    __tablename__ = "storage_locations"

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)

    name = Column(String(128), nullable=False)
    type = Column(String(16), nullable=False)  # "channel" or "group"
    telegram_chat_id = Column(BigInteger, nullable=False)
    is_default = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="storage_locations")
    files = relationship("FileRecord", back_populates="storage")


class Folder(Base):
    __tablename__ = "folders"

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    name = Column(String(128), nullable=False)
    parent_id = Column(Integer, ForeignKey("folders.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="folders")
    children = relationship("Folder", backref="parent", remote_side=[id])
    files = relationship("FileRecord", back_populates="folder")


class FileRecord(Base):
    __tablename__ = "files"

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    folder_id = Column(Integer, ForeignKey("folders.id"), nullable=True)
    storage_id = Column(Integer, ForeignKey("storage_locations.id"), nullable=False)

    original_filename = Column(String(255), nullable=False)
    size = Column(BigInteger, nullable=False, default=0)
    mime_type = Column(String(128), nullable=True)
    file_category = Column(String(32), nullable=True, index=True)  # image/video/document/audio/other

    telegram_chat_id = Column(BigInteger, nullable=False)
    telegram_message_id = Column(BigInteger, nullable=False)
    thumbnail_available = Column(Boolean, default=False)
    thumbnail_data = Column(Text, nullable=True)  # base64-encoded JPEG, small (~150px)

    is_trashed = Column(Boolean, default=False)
    uploaded_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="files")
    folder = relationship("Folder", back_populates="files")
    storage = relationship("StorageLocation", back_populates="files")
    shares = relationship("ShareLink", back_populates="file", cascade="all, delete-orphan")


class ShareLink(Base):
    """
    A revocable, optionally-expiring public link to download one file
    without logging into the website. The link never exposes Telegram
    credentials — it only carries an opaque random token that maps to
    this row.
    """
    __tablename__ = "share_links"

    id = Column(Integer, primary_key=True)
    file_id = Column(Integer, ForeignKey("files.id"), nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)

    token = Column(String(64), unique=True, nullable=False, index=True)
    expires_at = Column(DateTime, nullable=True)  # null = never expires
    is_revoked = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    download_count = Column(Integer, default=0)

    file = relationship("FileRecord", back_populates="shares")
