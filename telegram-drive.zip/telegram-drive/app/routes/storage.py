from fastapi import APIRouter, Request, Depends, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy.orm import Session

from app.database import get_db
from app.auth import get_current_user, get_or_create_csrf, require_csrf
from app.main_templates import templates
from app.models import TelegramAccount, StorageLocation, FileRecord
from app import telegram_service as tg
from urllib.parse import quote
from app.telegram_service import TelegramServiceError, ConnectedClient

router = APIRouter()


def _require_account(db, user_id):
    account = db.query(TelegramAccount).filter(TelegramAccount.user_id == user_id).first()
    if not account or not account.is_connected:
        return None
    return account


@router.get("/settings", response_class=HTMLResponse)
async def settings_page(request: Request, user=Depends(get_current_user), db: Session = Depends(get_db)):
    account = db.query(TelegramAccount).filter(TelegramAccount.user_id == user.id).first()
    locations = db.query(StorageLocation).filter(StorageLocation.user_id == user.id).all()

    counts = {loc.id: db.query(FileRecord).filter(
        FileRecord.storage_id == loc.id, FileRecord.is_trashed == False  # noqa: E712
    ).count() for loc in locations}

    return templates.TemplateResponse("settings.html", {
        "request": request, "user": user, "account": account, "locations": locations,
        "storage_locations": locations,
        "counts": counts, "csrf_token": get_or_create_csrf(request), "error": request.query_params.get("error"),
    })


@router.post("/storage/create")
async def create_storage(
    request: Request,
    name: str = Form(...),
    storage_type: str = Form(...),  # "channel" or "group"
    csrf_token: str = Form(...),
    user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    require_csrf(request, csrf_token)
    account = _require_account(db, user.id)
    if not account:
        return RedirectResponse("/setup", status_code=303)

    try:
        async with ConnectedClient(account) as client:
            if storage_type == "group":
                _, chat_id = await tg.create_group(client, name.strip())
            else:
                _, chat_id = await tg.create_channel(client, name.strip())
    except TelegramServiceError as e:
        return RedirectResponse(f"/settings?error={quote(e.message)}", status_code=303)

    is_first = db.query(StorageLocation).filter(StorageLocation.user_id == user.id).count() == 0
    location = StorageLocation(
        user_id=user.id, name=name.strip(), type=storage_type,
        telegram_chat_id=chat_id, is_default=is_first,
    )
    db.add(location)
    db.commit()
    return RedirectResponse("/settings", status_code=303)


@router.post("/storage/rename")
async def rename_storage(
    request: Request,
    storage_id: int = Form(...),
    new_name: str = Form(...),
    csrf_token: str = Form(...),
    user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    require_csrf(request, csrf_token)
    location = db.query(StorageLocation).filter(
        StorageLocation.id == storage_id, StorageLocation.user_id == user.id
    ).first()
    if not location:
        return RedirectResponse("/settings?error=Storage+not+found", status_code=303)

    account = _require_account(db, user.id)
    if not account:
        return RedirectResponse("/setup", status_code=303)

    try:
        async with ConnectedClient(account) as client:
            await tg.rename_chat(client, location.telegram_chat_id, new_name.strip())
    except TelegramServiceError as e:
        return RedirectResponse(f"/settings?error={quote(e.message)}", status_code=303)

    location.name = new_name.strip()
    db.commit()
    return RedirectResponse("/settings", status_code=303)


@router.post("/storage/set-default")
async def set_default_storage(
    request: Request,
    storage_id: int = Form(...),
    csrf_token: str = Form(...),
    user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    require_csrf(request, csrf_token)
    for loc in db.query(StorageLocation).filter(StorageLocation.user_id == user.id):
        loc.is_default = (loc.id == storage_id)
    db.commit()
    return RedirectResponse("/settings", status_code=303)


@router.post("/storage/delete")
async def delete_storage(
    request: Request,
    storage_id: int = Form(...),
    confirm: str = Form(...),
    csrf_token: str = Form(...),
    user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    require_csrf(request, csrf_token)
    if confirm != "DELETE":
        return RedirectResponse("/settings?error=Type+DELETE+to+confirm", status_code=303)

    location = db.query(StorageLocation).filter(
        StorageLocation.id == storage_id, StorageLocation.user_id == user.id
    ).first()
    if not location:
        return RedirectResponse("/settings?error=Storage+not+found", status_code=303)

    file_count = db.query(FileRecord).filter(FileRecord.storage_id == storage_id).count()
    if file_count > 0:
        return RedirectResponse(
            "/settings?error=Remove+or+move+all+files+from+this+storage+before+deleting+it",
            status_code=303,
        )

    account = _require_account(db, user.id)
    if account:
        try:
            async with ConnectedClient(account) as client:
                await tg.delete_storage_chat(client, location.telegram_chat_id, location.type)
        except TelegramServiceError as e:
            return RedirectResponse(f"/settings?error={quote(e.message)}", status_code=303)

    db.delete(location)
    db.commit()
    return RedirectResponse("/settings", status_code=303)
